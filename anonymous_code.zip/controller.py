
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable


class RBF(nn.Module):

    def __init__(self, input_size, output_size, basis_func):
        super().__init__()
        self.input_size = input_size
        self.output_size = output_size
        self.centres = nn.Parameter(torch.Tensor(output_size, input_size))
        self.sigmas = nn.Parameter(torch.Tensor(input_size))
        self.basis_func = basis_func
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.normal_(self.centres, 0, 1)
        nn.init.constant_(self.sigmas, 1)

    def forward(self, x):
        x = x.unsqueeze(1)
        c = self.centres.unsqueeze(0).cuda()
        s = self.sigmas.unsqueeze(0).cuda()
        sq_distances = ((x - c).pow(2) / torch.exp(s)).sum(-1)
        return self.basis_func(sq_distances)


class RBFNetwork(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, basis_func,
                 squash_func=None, output_bias=True):
        super().__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.rbf_layer = RBF(input_size, hidden_size, basis_func) 
        self.linear_layer = nn.Linear(in_features=hidden_size, out_features=output_size, bias=output_bias).cuda()
        self.batch_mode = True
        self.squash_func = squash_func

    def forward(self, x):
        hidden = self.rbf_layer(x)
        out = self.linear_layer(hidden)
        out = self.squash_func(out) if self.squash_func else out
        out = out if self.batch_mode else out.view(-1)
        
        return out

    def set_batch_mode(self, batch_mode):
        self.batch_mode = batch_mode


class RandomPolicy(nn.Module):

    def __init__(self, env, discrete_action_space=False):
        super().__init__()
        self.env = env
        self.discrete_action_space=discrete_action_space

    def forward(self, state):
        if self.discrete_action_space:
            action=Variable(torch.tensor(self.env.action_space.sample())) 
        else:
            action=Variable(torch.FloatTensor(self.env.action_space.sample()))
            
        return torch.FloatTensor(self.env.action_space.sample())

    
    
class MLPPolicy(nn.Module):

    def __init__(self, input_size, output_size, hidden_size=100, output_bias=False,
                 squash_func=None):
        super().__init__()

        self.input_size = input_size
        self.output_size = output_size
        self.hidden_size = hidden_size
        self.output_bias = output_bias
        self.squash_func = squash_func

        self.hidden_1 = nn.Linear(in_features=self.input_size,
                                  out_features=self.hidden_size,
                                  bias=True).cuda()
        self.hidden_2 = nn.Linear(in_features=self.hidden_size,
                                  out_features=self.hidden_size,
                                  bias=True).cuda()        
        self.out = nn.Linear(in_features=self.hidden_size,
                             out_features=self.output_size,
                             bias=output_bias).cuda()

    def forward(self, x):
        hidden1_out = torch.relu(self.hidden_1(x))
        hidden2_out = torch.relu(self.hidden_2(hidden1_out))
        out = self.out(hidden2_out)
        out = 2*torch.sigmoid(out)-1.0
        out = self.squash_func(out) if self.squash_func else out
        
        return out
    
    
    
def gaussian_rbf(sq_distances):
    phi = torch.exp(-0.5 * sq_distances)
    return phi



def sin_squash(unbounded_output, scale=10.):

    return scale*torch.sin(unbounded_output)



def tanh_squash(unbounded_output, scale=10.):

    return scale*torch.tanh(unbounded_output)

