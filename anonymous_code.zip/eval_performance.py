import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from data_collection import pn_ppo_rollout

num_steps=1000


def eval_ppo_in_env(env, env_name, agent, meta_dm, whether_lvm, check_lvm, 
                    x_memo_c, y_memo_c, stats, num_iter):

    rewards_arr = np.zeros([num_iter])

    for i in range(num_iter):
        states, actions, rewards = pn_ppo_rollout(env, env_name, agent, meta_dm, whether_lvm, check_lvm, 
                                                 x_memo_c, y_memo_c, stats)
        rewards_arr[i] = np.sum(rewards)
    
    return rewards_arr










