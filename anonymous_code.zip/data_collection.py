

import torch
import torch.nn as nn
import torch.utils.data as data
import torch.optim as optim
from torch.autograd import Variable
from meta_dms import normalize_dataset,denormalize_dataset 

import numpy as np


num_steps=1000

def rollout(env, policy, num_steps=num_steps):

    cur_state = env.reset()
    
    states = [cur_state]
    actions = []
    rewards = []
    
    for _ in range(num_steps-1):
        cur_state = torch.FloatTensor(cur_state).unsqueeze(0).cuda()
        action = torch.flatten(policy(cur_state))  
        action = action.data.cpu().numpy()
        next_state, reward, *_ = env.step(action) 
        
        actions.append(action)
        states.append(next_state)
        rewards.append(reward)
        
        cur_state = next_state
        
    states, actions, rewards = tuple(map(lambda l: np.stack(l, axis=0),
                                         (states, actions, rewards)))
    return states, actions, rewards
    


def pn_ppo_rollout(env, env_name, agent, meta_dm, whether_lvm, check_lvm, x_memo_c, y_memo_c, stats,
                   num_steps = num_steps, init_states = None, render = False):

    meta_dm.eval()
    
    for param in meta_dm.parameters():
        param.requires_grad = False
    
    x_memo_c_norm, y_memo_c_norm = normalize_dataset(stats, x_memo_c, var_order=0), normalize_dataset(stats, y_memo_c, var_order=3)
        
    if init_states is None:
        cur_states = torch.FloatTensor(env.reset()).cuda()        
    else:
        cur_states = torch.FloatTensor(init_states)
       
    state_list = [cur_states.data.cpu().numpy()]
    action_list = []
    reward_list = [] 

    if whether_lvm == True :
        if check_lvm == 'NP_DM' :
            mu_c,logvar_c,mu_t,logvar_t,y_pred=meta_dm(x_memo_c_norm,y_memo_c_norm,x_memo_c_norm,y_memo_c_norm,x_memo_c_norm)
            z_sample=meta_dm.reparameterization(mu_c,logvar_c)
        elif check_lvm == 'AttnNP_DM' : 
            mu_c,logvar_c,mu_t,logvar_t,y_pred=meta_dm(x_memo_c_norm,y_memo_c_norm,x_memo_c_norm,y_memo_c_norm,x_memo_c_norm)
            z_sample=meta_dm.reparameterization(mu_c,logvar_c)
        elif check_lvm == 'GS_DM' :
            mu_c,logvar_c,mu_t,logvar_t,y_pred=meta_dm(x_memo_c_norm,y_memo_c_norm,x_memo_c_norm)
            z_sample=meta_dm.reparameterization(torch.mean(mu_c,dim=1),torch.mean(logvar_c,dim=1))
            
    states = cur_states.unsqueeze(0)    
    if render: env.render()
    
    for t in range(num_steps-1):
        
        if whether_lvm:
            if isinstance(states,np.ndarray):
                states=torch.from_numpy(states).unsqueeze(0).cuda()
            preprocessed_states = dm_input_preporcess(states, env_name)
            normalized_states = normalize_dataset(stats, preprocessed_states, var_order=1)            
            z_sample_unsq_exp=z_sample.detach().squeeze(0).expand(normalized_states.size(0),-1)
            states_lv=torch.cat((normalized_states,z_sample_unsq_exp),dim=-1)               
            actions, action_log_probs = agent.act(states_lv.float())
        else:
            if isinstance(states,np.ndarray):
                states=torch.from_numpy(states).unsqueeze(0).cuda() 
            preprocessed_states = dm_input_preporcess(states, env_name)
            normalized_states = normalize_dataset(stats, preprocessed_states, var_order=1)            
            actions, action_log_probs = agent.act(normalized_states.float())
        
        actions = torch.flatten(actions).detach().cpu().numpy()   
        next_states, rewards, done, _ = env.step(actions) 
        
        if render: env.render()
        
        states = next_states
        
        state_list.append(states)
        action_list.append(actions)
        reward_list.append(rewards)
    
    state_list, action_list, reward_list = np.array(state_list), np.array(action_list), np.array(reward_list)
    for param in meta_dm.parameters():
        param.requires_grad = True    
        
    return state_list, action_list, reward_list




def convert_trajectory_to_training(states, actions, env_name, whether_preprocess = True):

    assert states.shape[0] == actions.shape[0] + 1
    obs, next_obs = states[:-1], states[1:]
    obs_act = np.concatenate((obs, actions), axis=1) 
    obs_diff = next_obs - obs
    
    if env_name == 'meta_ant':
        x = obs_act[...,1:] 
        y = np.concatenate([next_obs[..., :1], obs_diff[..., 1:]], axis=-1) 
    elif env_name == 'crippled_cheetah':
        if whether_preprocess:
            x = np.concatenate([obs_act[..., 1:2], np.sin(obs_act[..., 2:3]), np.cos(obs_act[..., 2:3]), obs_act[..., 3:]], axis=-1) 
            obs_x = np.concatenate([obs[..., 1:2], np.sin(obs[..., 2:3]), np.cos(obs[..., 2:3]), obs[..., 3:]], axis=-1) 
            next_obs_x = np.concatenate([next_obs[..., 1:2], np.sin(next_obs[..., 2:3]), np.cos(next_obs[..., 2:3]), next_obs[..., 3:]], axis=-1) 
            y = np.concatenate([next_obs[..., :1], next_obs_x - obs_x], axis=-1) 
        else:
            x = obs_act
            y = obs_diff            
    elif env_name == 'half_cheetah':
        if whether_preprocess:
            x = np.concatenate([obs_act[..., 1:2], np.sin(obs_act[..., 2:3]), np.cos(obs_act[..., 2:3]), obs_act[..., 3:]], axis=-1) 
            obs_x = np.concatenate([obs[..., 1:2], np.sin(obs[..., 2:3]), np.cos(obs[..., 2:3]), obs[..., 3:]], axis=-1) 
            next_obs_x = np.concatenate([next_obs[..., 1:2], np.sin(next_obs[..., 2:3]), np.cos(next_obs[..., 2:3]), next_obs[..., 3:]], axis=-1) 
            y = np.concatenate([next_obs[..., :1], next_obs_x - obs_x], axis=-1) 
        else:
            x = obs_act
            y = obs_diff            
    elif env_name == 'humanoid':
        x = obs_act 
        y = obs_diff 
    else:
        x = obs_act
        y = obs_diff        
    
    return x, y


def dm_input_preporcess(obs, env_name):

    if env_name == 'half_cheetah':
        if isinstance(obs, np.ndarray):
            state = np.concatenate([obs[..., 1:2], np.sin(obs[..., 2:3]), np.cos(obs[..., 2:3]), obs[..., 3:]], axis=-1) 
        else:
            state = torch.cat((obs[..., 1:2], torch.sin(obs[..., 2:3]), torch.cos(obs[..., 2:3]), obs[..., 3:]), -1) 
    elif env_name == 'humanoid':
        if isinstance(obs, np.ndarray):
            state = obs 
        else:
            state = obs 
    else:
        state = obs
    
    return state    
    
    

def dm_output_postprocess(state, delta, env_name):

    if env_name == 'half_cheetah':
        if isinstance(delta, np.ndarray):
            next_obs = np.concatenate([delta[..., :1], state + delta[..., 1:]], axis=-1)
        else:
            next_obs = torch.cat((delta[..., :1], state + delta[..., 1:]), -1) 
    elif env_name == 'humanoid':
        if isinstance(delta, np.ndarray):
            next_obs = state + delta
        else:
            next_obs = state + delta
    else:
        next_obs = state + delta
    
    return next_obs
            
            
    
class DynamicsDataBuffer(data.Dataset):
    def __init__(self, capacity=10000):
        self.data = []
        self.capacity = capacity
        
    def __len__(self) -> int:
        return len(self.data)
    
    def __getitem__(self, idx):
        x, y = self.data[idx]
        
        return torch.FloatTensor(x), torch.FloatTensor(y)
    
    def __getallitem__(self):
        x_list, y_list = [], []
        allitem = self.data
        for i in range(len(allitem)):
            x_item, y_item = allitem[i]
            x_list.append(x_item)
            y_list.append(y_item)
        x_arr, y_arr = np.array(x_list), np.array(y_list)
        
        return torch.FloatTensor(x_arr), torch.FloatTensor(y_arr)

    def __repr__(self):
        return f'Dynamics Data Buffer with {len(self.data)} / {self.capacity} elements.\n'

    def push(self, x: np.ndarray, y: np.ndarray):
        if x.ndim == 1:
            assert y.ndim == 1
            x = x[None, :]
            y = y[None, :]
            
        for i in range(x.shape[0]):
            self.data.append((x[i], y[i]))
            
        if len(self.data) > self.capacity:
            del self.data[:len(self.data) - self.capacity]
    
    
