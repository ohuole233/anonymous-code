
import os
import sys
import gym
from gym import wrappers
import random
import numpy as np
import math

import mujoco_py

import torch
import torch.optim as optim
import torch.multiprocessing as mp
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable



num_steps=1000


class ReplayMemory(object):
    def __init__(self, capacity):
        self.capacity = capacity
        self.memory = []

    def push(self, events):
        for event in zip(*events):
            self.memory.append(event)
            if len(self.memory)>self.capacity:
                del self.memory[0]

    def clear(self):
        self.memory = []

    def sample(self, batch_size):
        samples = zip(*random.sample(self.memory, batch_size))
        return map(lambda x: torch.cat(x, 0), samples)


def kl_div_prior(z_mu,logvar):
    
    kld_sum=-0.5*torch.sum(1+logvar-z_mu.pow(2)-logvar.exp())
    if z_mu.dim()==2:
        kld=(torch.mean(kld_sum,dim=0)).sum() 
    elif z_mu.dim()==3:
        kld=(torch.mean(kld_sum,dim=[0,1])).sum() 
    
    return kld



     
###########################train policy in dm using PPO#################################################

def train_ppo_in_dm(meta_dm: nn.Module, env, env_name, agent, optimizer, whether_lvm: bool, check_lvm: str, 
                    x_memo_c, y_memo_c, stats, meta_rewards_torch, clip = 0.2, num_episode = 100, num_epoch = 10, 
                    num_steps = 1000, gamma = 0.99, gae_param = 0.95, ent_coeff = 0.01, memo_bsize = 64, 
                    max_grad_norm = 0.5, render = False, collect_memory = True):

    meta_dm.eval()

    for param in meta_dm.parameters():
        param.requires_grad = False 
        
    if collect_memory:
        x_memo_c_norm, y_memo_c_norm = normalize_dataset(stats, x_memo_c, var_order=0), normalize_dataset(stats, y_memo_c, var_order=3)

    if whether_lvm == True :
        if check_lvm == 'NP_DM' :
            mu_c,logvar_c,mu_t,logvar_t,y_pred=meta_dm(x_memo_c_norm,y_memo_c_norm,x_memo_c_norm,y_memo_c_norm,x_memo_c_norm)
            z_sample=meta_dm.reparameterization(mu_c,logvar_c)
        elif check_lvm == 'AttnNP_DM' : 
            mu_c,logvar_c,mu_t,logvar_t,y_pred=meta_dm(x_memo_c_norm,y_memo_c_norm,x_memo_c_norm,y_memo_c_norm,x_memo_c_norm)
            z_sample=meta_dm.reparameterization(mu_c,logvar_c)
        elif check_lvm == 'GS_DM' :
            mu_c,logvar_c,mu_t,logvar_t,y_pred=meta_dm(x_memo_c_norm,y_memo_c_norm,x_memo_c_norm)
            z_sample=meta_dm.reparameterization(torch.mean(mu_c,dim=1),torch.mean(logvar_c,dim=1)) 
    
    
    memory = ReplayMemory(num_steps)
    state = env.reset()
    state = Variable(torch.Tensor(state).unsqueeze(0))
    done = True
    episode = -1

    for t in range(num_episode):
        
        episode_length = 0

        while(len(memory.memory)<num_steps):
            states = [] 
            actions = [] 
            rewards = []
            values = []
            returns = []
            advantages = []
            logprobs = []
            av_reward = 0
            cum_reward = 0
            cum_done = 0

            for step in range(num_steps):
                episode_length += 1
                
                if step==0:    
                    preprocessed_state = (dm_input_preporcess(state, env_name)).cuda()
                else:
                    preprocessed_state = (dm_input_preporcess(state, env_name, init_state=False)).cuda()
                state = normalize_dataset(stats, preprocessed_state, var_order=1) 

                if whether_lvm:
                    z_sample_unsq_exp=z_sample.detach().squeeze(0).expand(state.size(0),-1)
                    state_lv=torch.cat((state,z_sample_unsq_exp),dim=-1) 
                    
                    v, action, log_prob = agent.act(state_lv.float(),return_v=True)
                    states.append(state_lv)
                else:
                    v, action, log_prob = agent.act(state,return_v=True)
                    states.append(state)
                    
                actions.append(action)
                logprobs.append(log_prob)
                values.append(v)
                
                normalized_action = normalize_dataset(stats, action, var_order=2)  
                state_action_tensor = (torch.cat((state, normalized_action), dim=-1)).unsqueeze(0) 
            
                if check_lvm == 'NP_DM' :
                    mu_c, logvar_c, mu_t, logvar_t, delta_usq = meta_dm(x_memo_c_norm,y_memo_c_norm,x_memo_c_norm,y_memo_c_norm,state_action_tensor)
                elif check_lvm == 'AttnNP_DM' :
                    mu_c, logvar_c, mu_t, logvar_t, delta_usq=meta_dm(x_memo_c_norm,y_memo_c_norm,x_memo_c_norm,y_memo_c_norm,state_action_tensor)
                elif check_lvm == 'GS_DM' :
                    mu_c, logvar_c, mu_t, logvar_t, delta_usq=meta_dm(x_memo_c_norm,y_memo_c_norm,state_action_tensor)
                else:
                    delta_usq = meta_dm(state_action_tensor)  
                
                denormalized_delta = denormalize_dataset(stats, delta_usq.squeeze(0), var_order=3)
                denormalized_state = denormalize_dataset(stats, state, var_order=1) 
                
                denormalized_next_state = dm_output_postprocess(denormalized_state, denormalized_delta, env_name) 

                reward = (meta_rewards_torch(denormalized_state,action,denormalized_next_state)).item()

                done = (episode_length >= num_steps)
                cum_reward += reward
                reward = max(min(reward, 1), -1)
                rewards.append(reward)
                
                state = denormalized_next_state
                
                if done:
                    episode += 1
                    cum_done += 1
                    av_reward += cum_reward
                    cum_reward = 0
                    episode_length = 0
                    state = env.reset()
                    state = Variable(torch.Tensor(state).unsqueeze(0)).cuda()
                
                if done:
                    break

            R = torch.zeros(1, 1)
            if not done:
                last_state = dm_input_preporcess(state, env_name)
                last_state = normalize_dataset(stats, last_state, var_order=1)             
                if whether_lvm:
                    z_sample_unsq_exp=z_sample.detach().squeeze(0).expand(last_state.size(0),-1)
                    state_lv=torch.cat((state,z_sample_unsq_exp),dim=-1) 
                    v, action, log_prob = agent.act(state_lv.float(),return_v=True)
                else:
                    v, action, log_prob = agent.act(last_state,return_v=True)
                
                R = v.data

            R = Variable(R)
            values.append(R)
            A = Variable(torch.zeros(1, 1)).cuda()
            for i in reversed(range(len(rewards))):
                td = rewards[i] + gamma*values[i+1].data[0,0] - values[i].data[0,0]
                A = float(td) + gamma*gae_param*A
                advantages.insert(0, A)
                R = A + values[i]
                returns.insert(0, R)

            memory.push([states, actions, returns, advantages, logprobs])

        for k in range(num_epoch):
            batch_states, batch_actions, batch_returns, batch_advantages, batch_logprobs = memory.sample(memo_bsize)
            batch_actions = Variable(batch_actions.data, requires_grad=False)
            batch_states = Variable(batch_states.data, requires_grad=False)
            batch_returns = Variable(batch_returns.data, requires_grad=False)
            batch_advantages = Variable(batch_advantages.data, requires_grad=False)
            batch_logprobs = Variable(batch_logprobs.data, requires_grad=False)

            mu, sigma_sq, v_pred = agent(batch_states)
            log_std = agent.log_std
            log_probs = -0.5 * ((batch_actions - mu) / (sigma_sq+1e-8)).pow(2) - 0.5 * math.log(2 * math.pi) - log_std
            log_probs = log_probs.sum(-1, keepdim=True)
            dist_entropy = 0.5 + 0.5 * math.log(2 * math.pi) + log_std
            dist_entropy = dist_entropy.sum(-1).mean()

            ratio = torch.exp(log_probs - batch_logprobs)

            surr1 = ratio * batch_advantages.expand_as(ratio) 
            surr2 = ratio.clamp(1-clip, 1+clip) * batch_advantages.expand_as(ratio)
            loss_clip = - torch.mean(torch.min(surr1, surr2))
            loss_value = (v_pred - batch_returns).pow(2).mean()
            loss_ent = - ent_coeff * dist_entropy

            total_loss = (loss_clip + loss_value + loss_ent)
            optimizer.zero_grad()
            total_loss.backward()
            nn.utils.clip_grad_norm(agent.parameters(), max_grad_norm)
            optimizer.step()

        memory.clear()
        
    return agent


def eval_pearl_in_env(env, env_name, policy_model, context_model, shared_obs_stats, z_sample, stats, num_iter, collect_memory = True):
    
    rewards_arr = np.zeros([num_iter])

    for i in range(num_iter):
        reward_list = pearl_rollout(env, env_name, policy_model, context_model, shared_obs_stats, z_sample, stats, collect_memory = True)
        rewards_arr[i] = np.sum(reward_list)
    
    return rewards_arr




def eval_ppo_in_env(env, env_name, agent, meta_dm, whether_lvm, check_lvm, 
                    x_memo_c, y_memo_c, stats, num_iter, collect_memory):
    
    rewards_arr = np.zeros([num_iter])

    for i in range(num_iter):
        states, actions, rewards = pn_ppo_rollout(env, env_name, agent, meta_dm, whether_lvm, check_lvm, 
                                                 x_memo_c, y_memo_c, stats, collect_memory)
        rewards_arr[i] = np.sum(rewards)
    
    return rewards_arr



def pn_ppo_rollout(env, env_name, agent, meta_dm, whether_lvm, check_lvm, x_memo_c, y_memo_c, stats, collect_memory,
                   num_steps = 1000, init_states = None, render = False):
    meta_dm.eval()
    
    for param in meta_dm.parameters():
        param.requires_grad = False
    
    if collect_memory:
        x_memo_c_norm, y_memo_c_norm = normalize_dataset(stats, x_memo_c, var_order=0), normalize_dataset(stats, y_memo_c, var_order=3)
        
    if init_states is None:
        cur_states = torch.FloatTensor(env.reset()).cuda()        
    else:
        cur_states = torch.FloatTensor(init_states)
       
    state_list = [cur_states.data.cpu().numpy()]
    action_list = []
    reward_list = [] 

    if whether_lvm == True :
        if check_lvm == 'NP_DM' :
            mu_c,logvar_c,mu_t,logvar_t,y_pred=meta_dm(x_memo_c_norm,y_memo_c_norm,x_memo_c_norm,y_memo_c_norm,x_memo_c_norm)
            z_sample=meta_dm.reparameterization(mu_c,logvar_c)
        elif check_lvm == 'AttnNP_DM' : 
            mu_c,logvar_c,mu_t,logvar_t,y_pred=meta_dm(x_memo_c_norm,y_memo_c_norm,x_memo_c_norm,y_memo_c_norm,x_memo_c_norm)
            z_sample=meta_dm.reparameterization(mu_c,logvar_c)
        elif check_lvm == 'GS_DM' :
            mu_c,logvar_c,mu_t,logvar_t,y_pred=meta_dm(x_memo_c_norm,y_memo_c_norm,x_memo_c_norm)
            z_sample=meta_dm.reparameterization(torch.mean(mu_c,dim=1),torch.mean(logvar_c,dim=1))
            
    states = cur_states.unsqueeze(0)       
    if render: env.render()
    
    for t in range(num_steps-1):
        
        if whether_lvm:
            if isinstance(states,np.ndarray):
                states=torch.from_numpy(states).unsqueeze(0).cuda()
            
            preprocessed_states = dm_input_preporcess(states, env_name)
            normalized_states = normalize_dataset(stats, preprocessed_states, var_order=1)            
            z_sample_unsq_exp=z_sample.detach().squeeze(0).expand(normalized_states.size(0),-1)
            states_lv=torch.cat((normalized_states,z_sample_unsq_exp),dim=-1)                
            actions, action_log_probs = agent.act(states_lv.float())
        else:
            if isinstance(states,np.ndarray):
                states=torch.from_numpy(states).unsqueeze(0).cuda() 
            
            preprocessed_states = dm_input_preporcess(states, env_name)
            normalized_states = normalize_dataset(stats, preprocessed_states, var_order=1)            
            actions, action_log_probs = agent.act(normalized_states.float())
        
        actions = torch.flatten(actions).detach().cpu().numpy() 
        next_states, rewards, done, _ = env.step(actions) 
        
        if render: env.render()
        
        states = next_states
        
        state_list.append(states)
        action_list.append(actions)
        reward_list.append(rewards)
    
    state_list, action_list, reward_list = np.array(state_list), np.array(action_list), np.array(reward_list)

    for param in meta_dm.parameters():
        param.requires_grad = True    
        
    return state_list, action_list, reward_list



def normalize_dataset(stats, x, var_order):
 
    (s_mean,s_std,a_mean,a_std,s_diff_mean,s_diff_std)=stats
    
    if var_order==0:
        sa_mean,sa_std=np.concatenate((s_mean,a_mean)),np.concatenate((s_std,a_std))
        sa_mean_tensor,sa_std_tensor=torch.FloatTensor(sa_mean).cuda(),torch.FloatTensor(sa_std).cuda()
        mean_exp,std_exp=sa_mean_tensor.expand_as(x),sa_std_tensor.expand_as(x)
        
    elif var_order==1:
        s_mean_tensor,s_std_tensor=torch.FloatTensor(s_mean).cuda(),torch.FloatTensor(s_std).cuda()
        mean_exp,std_exp=s_mean_tensor.expand_as(x),s_std_tensor.expand_as(x)
        
    elif var_order==2:
        a_mean_tensor,a_std_tensor=torch.FloatTensor(a_mean).cuda(),torch.FloatTensor(a_std).cuda()
        mean_exp,std_exp=a_mean_tensor.expand_as(x),a_std_tensor.expand_as(x)
        
    elif var_order==3:
        s_diff_mean_tensor,s_diff_std_tensor=torch.FloatTensor(s_diff_mean).cuda(),torch.FloatTensor(s_diff_std).cuda()
        mean_exp,std_exp=s_diff_mean_tensor.expand_as(x),s_diff_std_tensor.expand_as(x)        
    
    normalized_x=(x-mean_exp)/(std_exp+1e-10)
    
    return normalized_x
                 
                                                                    
def denormalize_dataset(stats, normalized_x, var_order):

    (s_mean,s_std,a_mean,a_std,s_diff_mean,s_diff_std)=stats
    
    if var_order==0:
        sa_mean,sa_std=np.concatenate((s_mean,a_mean)),np.concatenate((s_std,a_std))
        sa_mean_tensor,sa_std_tensor=torch.FloatTensor(sa_mean).cuda(),torch.FloatTensor(sa_std).cuda()
        mean_exp,std_exp=sa_mean_tensor.expand_as(normalized_x),sa_std_tensor.expand_as(normalized_x)
        
    elif var_order==1:
        s_mean_tensor,s_std_tensor=torch.FloatTensor(s_mean).cuda(),torch.FloatTensor(s_std).cuda()
        mean_exp,std_exp=s_mean_tensor.expand_as(normalized_x),s_std_tensor.expand_as(normalized_x)
        
    elif var_order==2:
        a_mean_tensor,a_std_tensor=torch.FloatTensor(a_mean).cuda(),torch.FloatTensor(a_std).cuda()
        mean_exp,std_exp=a_mean_tensor.expand_as(normalized_x),a_std_tensor.expand_as(normalized_x) 
        
    elif var_order==3:
        s_diff_mean_tensor,s_diff_std_tensor=torch.FloatTensor(s_diff_mean).cuda(),torch.FloatTensor(s_diff_std).cuda()
        mean_exp,std_exp=s_diff_mean_tensor.expand_as(normalized_x),s_diff_std_tensor.expand_as(normalized_x)        
    
    x=normalized_x*(std_exp+1e-10)+mean_exp
    
    return x



def dm_input_preporcess(obs, env_name, init_state=True):

    if env_name == 'half_cheetah':
        if isinstance(obs, np.ndarray):
            if init_state:
                state = np.concatenate([obs[..., 1:2], np.sin(obs[..., 2:3]), np.cos(obs[..., 2:3]), obs[..., 3:]], axis=-1)
            else:
                state = obs[...,1:]
        else:
            if init_state:
                state = torch.cat((obs[..., 1:2], torch.sin(obs[..., 2:3]), torch.cos(obs[..., 2:3]), obs[..., 3:]), -1)
            else:
                state = obs[...,1:]
    elif env_name == 'humanoid':
        if isinstance(obs, np.ndarray):
            state = obs
        else:
            state = obs
    else:
        state = obs
    
    return state  



def dm_output_postprocess(denormalized_state, denormalized_delta, env_name):

    if env_name == 'half_cheetah':
        if isinstance(denormalized_delta, np.ndarray):
            next_obs = np.concatenate([denormalized_delta[..., :1], denormalized_state + denormalized_delta[..., 1:]], axis=-1)
        else:
            next_obs = torch.cat((denormalized_delta[..., :1], denormalized_state + denormalized_delta[..., 1:]), -1) 
    elif env_name == 'humanoid':
        next_obs = denormalized_state + denormalized_delta
    else:
        next_obs = denormalized_state + denormalized_delta
    
    return next_obs
