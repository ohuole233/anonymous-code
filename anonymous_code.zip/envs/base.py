from .env_spec import EnvSpec
from abc import ABC, abstractmethod
import collections
import gym


class Env(object):
    def step(self, action):
        raise NotImplementedError

    def reset(self):
        raise NotImplementedError

    @property
    def action_space(self):
        raise NotImplementedError

    @property
    def observation_space(self):
        raise NotImplementedError

    @property
    def action_dim(self):
        return self.action_space.flat_dim

    def render(self):
        pass

    def log_diagnostics(self, paths):
        pass

    @property
    def spec(self):
        return EnvSpec(
            observation_space=self.observation_space,
            action_space=self.action_space,
        )

    @property
    def horizon(self):
        raise NotImplementedError


    def terminate(self):
        pass


_Step = collections.namedtuple("Step", ["observation", "reward", "done", "info"])


def Step(observation, reward, done, **kwargs):

    return _Step(observation, reward, done, kwargs)


class BaseGymEnvironment(gym.Env):

    @property
    def parameters(self):
        return {
            'id': self.spec.id,
        }


class EnvBinarySuccessMixin(ABC):

    @abstractmethod
    def is_success(self):
        pass


