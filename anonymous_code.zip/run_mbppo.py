
import torch
import torch.nn as nn
import numpy as np
import gym

from data_collection import *
from meta_dms import *
from param_list import *
from dm_training import *
from eval_performance import *
from controller import *
from meta_loss import *
from utils import *

from envs.normalized_env import normalize
from mfrl_utils.ppo import train_ppo_in_dm
from mfrl_utils.ppo_model import Model, Shared_obs_stats


dm_type='GS_DM' # Graph Structured Surrogate Model
use_lvm=True
env_name='humanoid'

torch.set_default_dtype(torch.float32)


if env_name=='half_cheetah':
    from envs.Meta_Halfcheetah import sample_env, metacheetah_cost_torch, metacheetah_reward_torch
    dim_obs=18
    dim_s=18
    dim_action=6
    act_scale=1.0
    cost_function=metacheetah_cost_torch 
    reward_function=metacheetah_reward_torch
    #torch.manual_seed(2020)

elif env_name=='humanoid':
    from envs.Meta_Humanoid import sample_env, metahumanoid_cost_torch, metahumanoid_reward_torch
    dim_obs=45
    dim_s=45
    dim_action=17
    act_scale=0.4
    cost_function=metahumanoid_cost_torch 
    reward_function=metahumanoid_reward_torch
    #torch.manual_seed(2020)


args_gsdm=GSDM_Param()
args_npdm=NPDM_Param()
args_attnnpdm=AttnNPDM_Param()
args_bnndm=BNNDM_Param()


if use_lvm:
    Agent = Model(num_inputs=dim_obs+args_gsdm.dim_lat, num_outputs=dim_action).cuda() 
    optimizer = optim.Adam(Agent.parameters(), lr=5e-4)    
else:
    Agent = Model(num_inputs=dim_obs, num_outputs=dim_action).cuda() 
    optimizer = optim.Adam(Agent.parameters(), lr=5e-4)        


if dm_type=='GS_DM':
    dm_net = GS_DM(args_gsdm).float()
elif dm_type=='NP_DM':
    dm_net = NP_DM(args_npdm).float()
elif dm_type=='AttnNP_DM':
    dm_net = AttnNP_DM(args_attnnpdm).float()
elif dm_type=='BNN_DM':
    dm_net = BNN_DM(args_bnndm).float()
    
dm_opt = torch.optim.Adam(dm_net.parameters(), lr=1e-3)
dm_optim_scheduler = torch.optim.lr_scheduler.StepLR(dm_opt, step_size=100, gamma=0.9)


def main_exp_mbmf(dm_net,dm_opt,whether_lvm,check_lvm,num_tasks=100,
                  num_trial_steps=25,num_init_traj=10,dm_b_size=100,
                  num_pl_iter=1000,num_memo_traj=1,num_eval_traj=40,task_iter=100):
    
    dm_tr_loss_list, dm_tr_mse_list, dm_te_mse_list, reward_te_list = np.zeros((num_tasks,task_iter)), \
        np.zeros((num_tasks,task_iter)), np.zeros((num_tasks,task_iter)), np.zeros((num_tasks,task_iter))
    
    for i in range(num_tasks):
        env=sample_env()
        env=normalize(env)

        rand_policy = RandomPolicy(env)
        
        dm_buffer = DynamicsDataBuffer(capacity=num_trial_steps*num_init_traj)
        for _ in range(num_init_traj):
            states, actions, rewards = rollout(env, rand_policy, num_steps=num_trial_steps)
            dm_buffer.push(*convert_trajectory_to_training(states, actions, env_name))
        x_all, y_all = dm_buffer.__getallitem__() 
        stats = get_stats(x=x_all, y=y_all, dim_s=dim_s)
        dm_dataloader = torch.utils.data.DataLoader(dm_buffer, batch_size=dm_b_size, shuffle=True)        
        
        memo_buffer = DynamicsDataBuffer(capacity=500*num_memo_traj)
        for _ in range(num_memo_traj):
            states, actions, rewards = rollout(env, rand_policy, num_steps=500)
            memo_buffer.push(*convert_trajectory_to_training(states, actions, env_name))  
        x_memo_c, y_memo_c = memo_buffer.__getallitem__()
        x_memo_c, y_memo_c = x_memo_c.unsqueeze(0).cuda(), y_memo_c.unsqueeze(0).cuda()            
          
         
        test_dm_buffer = DynamicsDataBuffer(capacity=num_trial_steps*num_eval_traj)
        for _ in range(num_eval_traj):
            states, actions, rewards = rollout(env, rand_policy, num_steps=num_trial_steps)
            test_dm_buffer.push(*convert_trajectory_to_training(states, actions, env_name))
        test_dm_loader = torch.utils.data.DataLoader(test_dm_buffer, batch_size=dm_b_size, shuffle=False, drop_last=True)
            
        for j in range(task_iter):
            
            b_dm_train_loss, b_dm_train_mse = train_meta_dm(dm_net, stats, dm_opt, dm_dataloader, check_lvm, 
                                                            loss_fun=mse_kl_loss, epoch=5) 
            avg_b_dm_train_loss, avg_b_dm_train_mse = np.mean(b_dm_train_loss), np.mean(b_dm_train_mse)

            dm_tr_loss_list[i,j], dm_tr_mse_list[i,j] = avg_b_dm_train_loss, avg_b_dm_train_mse
            
            b_dm_test_mse = test_meta_dm(dm_net, x_memo_c, y_memo_c, stats,
                                         test_dm_loader, check_lvm, loss_fun=mse_loss) 
            dm_te_mse_list[i,j] = b_dm_test_mse
            
            agent = train_ppo_in_dm(meta_dm=dm_net, env=env, env_name=env_name, agent=Agent, optimizer=optimizer, whether_lvm=whether_lvm, 
                                    check_lvm=check_lvm, x_memo_c=x_memo_c, y_memo_c=y_memo_c, stats=stats, meta_rewards_torch=reward_function,
                                    num_steps=num_trial_steps, num_episode=5)
            
            rewards_arr = eval_ppo_in_env(env, env_name, agent, dm_net, whether_lvm, check_lvm, 
                                          x_memo_c, y_memo_c, stats, num_iter=50) 
            avg_rewards=np.mean(rewards_arr)
            reward_te_list[i,j] = avg_rewards
            
            states, actions, rewards = pn_ppo_rollout(env, env_name, agent, dm_net, whether_lvm, check_lvm, 
                                                      x_memo_c, y_memo_c, stats, num_steps=num_steps)
            
            dm_buffer.push(*convert_trajectory_to_training(states, actions, env_name))
            
            dm_optim_scheduler.step()            

    torch.save(dm_net.state_dict(), './runs/GS_NP/dm_net.pt')
    torch.save(agent.state_dict(), './runs/GS_NP/ppo_net.pt')
    np.save('./runs/GS_NP/dm_tr_loss_list.npy', dm_tr_loss_list)
    np.save('./runs/GS_NP/dm_tr_mse_list.npy', dm_tr_mse_list)
    np.save('./runs/GS_NP/dm_te_mse_list.npy', dm_te_mse_list)
    np.save('./runs/GS_NP/reward_te_list.npy', reward_te_list)
        


main_exp_mbmf(dm_net,dm_opt,whether_lvm=use_lvm,check_lvm=dm_type,num_tasks=50,
              num_trial_steps=1000,num_init_traj=2,dm_b_size=1000,num_pl_iter=1,
              num_memo_traj=1,num_eval_traj=5,task_iter=2)






